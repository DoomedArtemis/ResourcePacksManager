﻿Artemis Enhanced Visuals
For Minecraft Java Edition 1.18.1

A collection of Artemis resource packs that enhances Minecraft's vanilla visuals while preserving its familiar style.

How to use
1. Open Minecraft and go to Options > Resource Packs > Open Pack Folder.
2. Place this ZIP in the folder that opens.
3. Return to Resource Packs, move this pack to Selected, and click Done.

The resource packs listed below are already included. You can use this pack on its own.

Included packs and versions
Alternative Birch Leaves: 1.0.0
Alternative End Rod: 1.0.0
Alternative Nether Portal Color: 1.0.0
Better Cake Slices: 1.0.0
Better Candles: 1.0.0
Better Carpets: 1.1.0
Better Moss: 1.0.0
Flowering Lily Pads: 1.0.0
Flowering Oak Leaves: 1.0.0
Vanilla Lavender Enhanced: 1.0.0

Credits and license
See credits.txt for the artists and original creators whose work is included in this pack.
See license.txt for license information.
Additional license notices are included in the licenses folder.
